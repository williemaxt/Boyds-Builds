// make shift anchors that act as buttons
//declaration of page elements to be changed
//functions
function viewMore(){
  alert("Hello, the button worked");
  //homeUl.innerHTML("<h1>New List<h1>");
  document.getElementById('homeUl').innerHTML("<h1>New List<h1>");
}
